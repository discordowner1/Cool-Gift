import { useState, useEffect } from "react";

type AppState = 'initial' | 'prize' | 'video';

export default function RickrollPage() {
  const [currentState, setCurrentState] = useState<AppState>('initial');
  const [countdown, setCountdown] = useState(3);
  const [prizeText, setPrizeText] = useState('🎁 Cool prize incoming...');

  useEffect(() => {
    // Phase 1: Show initial loading for 3 seconds
    const initialTimer = setTimeout(() => {
      setCurrentState('prize');
      
      // Phase 2: Start countdown after a brief transition delay
      setTimeout(() => {
        startCountdown();
      }, 500);
    }, 3000);

    return () => clearTimeout(initialTimer);
  }, []);

  const startCountdown = () => {
    let currentCount = 3;
    
    // Set initial state immediately
    setCountdown(currentCount);
    setPrizeText('🎁 Cool prize incoming...');
    
    const countdownInterval = setInterval(() => {
      currentCount--;
      
      if (currentCount > 0) {
        setCountdown(currentCount);
        
        // Update prize text based on countdown
        if (currentCount === 2) {
          setPrizeText('🎯 Almost ready...');
        } else if (currentCount === 1) {
          setPrizeText('🚀 Here it comes...');
        }
      } else {
        // When countdown reaches 0, show the rickroll
        clearInterval(countdownInterval);
        setCountdown(0);
        setPrizeText('🎉 Your prize is ready!');
        
        // Brief pause before showing rickroll for better effect
        setTimeout(() => {
          setCurrentState('video');
        }, 300);
      }
    }, 1000);
  };

  const renderInitialState = () => (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="text-center animate-fade-in">
        <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
        <h1 className="text-2xl font-semibold text-gray-800 mb-2">Verifying Your Entry...</h1>
        <p className="text-gray-600">Please wait while we confirm your eligibility</p>
      </div>
    </div>
  );

  const renderPrizeState = () => (
    <div className="flex items-center justify-center min-h-screen p-4 bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="bg-white rounded-2xl shadow-2xl prize-glow p-8 max-w-md w-full text-center animate-slide-up">
        {/* Celebration Icons */}
        <div className="text-6xl mb-4 animate-bounce-slow">🎉</div>
        
        {/* Main Prize Text */}
        <h1 className="text-3xl font-bold text-gray-800 mb-4">
          Congratulations!
        </h1>
        
        <div className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-6 py-3 rounded-lg mb-6 animate-pulse-slow">
          <p className="text-xl font-semibold">You've Won a Special Prize! 🏆</p>
        </div>
        
        <p className="text-gray-600 mb-6 leading-relaxed">
          You are one of our lucky visitors today! Your amazing prize is being prepared...
        </p>
        
        {/* Prize Loading Message */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <p className="text-blue-800 font-medium">
            {prizeText}
          </p>
        </div>
        
        {/* Countdown Display */}
        <div className="text-center">
          <p className="text-gray-500 text-sm mb-2">Revealing your prize in:</p>
          <div className="text-5xl font-bold text-blue-600 animate-pulse">{countdown}</div>
        </div>
      </div>
    </div>
  );

  const renderVideoState = () => (
    <div className="relative flex items-center justify-center min-h-screen bg-black">
      <div className="w-full max-w-4xl aspect-video mx-4">
        {/* YouTube Rickroll Video Embed */}
        <iframe 
          width="100%" 
          height="100%" 
          src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1&start=0&controls=1&rel=0&modestbranding=1" 
          title="Your Special Prize!" 
          frameBorder="0" 
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
          allowFullScreen
          className="rounded-lg shadow-2xl"
        />
      </div>
      
      {/* Rickroll Message Overlay */}
      <div className="absolute top-4 left-4 right-4 text-center">
        <div className="bg-black bg-opacity-75 text-white px-6 py-3 rounded-lg inline-block animate-fade-in">
          <p className="text-xl font-semibold">🎵 You've been Rickrolled! 🎵</p>
          <p className="text-sm mt-1">Never gonna give you up! 😄</p>
        </div>
      </div>
    </div>
  );

  // Render current state
  switch (currentState) {
    case 'initial':
      return renderInitialState();
    case 'prize':
      return renderPrizeState();
    case 'video':
      return renderVideoState();
    default:
      return renderInitialState();
  }
}
