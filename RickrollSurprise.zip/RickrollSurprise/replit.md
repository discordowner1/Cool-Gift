# Rickroll Application

## Overview

This is a React-based web application that presents itself as a "prize winner" interface but is actually a rickroll application. The app creates a deceptive user experience by showing loading screens and countdown timers before revealing a Rick Astley video.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React hooks for local state, TanStack Query for server state
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ESM modules
- **Development**: tsx for TypeScript execution in development
- **Production**: esbuild for bundling server code

### Database Layer
- **ORM**: Drizzle ORM
- **Database**: PostgreSQL (configured for Neon Database)
- **Schema Management**: Drizzle Kit for migrations
- **Connection**: @neondatabase/serverless for serverless PostgreSQL connections

## Key Components

### Frontend Structure
- **Entry Point**: `client/src/main.tsx` - React application root
- **Router**: `client/src/App.tsx` - Main app component with wouter routing
- **Main Page**: `client/src/pages/rickroll.tsx` - The rickroll interface with state management
- **UI Components**: `client/src/components/ui/` - shadcn/ui component library
- **Utilities**: `client/src/lib/` - Utility functions and query client setup

### Backend Structure
- **Server Entry**: `server/index.ts` - Express server with middleware setup
- **Routes**: `server/routes.ts` - API route definitions (currently minimal)
- **Storage**: `server/storage.ts` - In-memory storage implementation with interface
- **Vite Integration**: `server/vite.ts` - Development server with Vite middleware

### Database Schema
- **Users Table**: Basic user management with id, username, and password fields
- **Validation**: Zod schemas for type-safe data validation
- **Types**: Generated TypeScript types from Drizzle schema

## Data Flow

1. **Client Request**: React app makes requests through TanStack Query
2. **API Layer**: Express routes handle HTTP requests
3. **Storage Layer**: Interface-based storage system (currently in-memory)
4. **Database**: Drizzle ORM manages PostgreSQL interactions
5. **Response**: JSON responses sent back to client

The rickroll page manages its own state progression:
- Initial loading state (3 seconds)
- Prize announcement with countdown (3 seconds)
- Video reveal (rickroll)

## External Dependencies

### Core Dependencies
- **React Ecosystem**: React, React DOM, React Router (wouter)
- **UI Framework**: Radix UI primitives, shadcn/ui components, Tailwind CSS
- **Backend**: Express.js, Drizzle ORM, Neon Database client
- **Development**: Vite, TypeScript, tsx, esbuild
- **Utilities**: TanStack Query, date-fns, clsx, class-variance-authority

### Development Tools
- **Replit Integration**: Vite plugins for Replit environment
- **Database Tools**: Drizzle Kit for schema management
- **Session Management**: connect-pg-simple for PostgreSQL sessions

## Deployment Strategy

### Development
- **Dev Server**: `npm run dev` - Runs tsx server with Vite middleware
- **Hot Reload**: Vite provides fast HMR for frontend changes
- **Database**: Uses Drizzle Kit for schema synchronization

### Production
- **Build Process**: 
  1. `vite build` - Builds React app to `dist/public`
  2. `esbuild` - Bundles server code to `dist/index.js`
- **Start**: `npm start` - Runs bundled server in production mode
- **Static Assets**: Express serves built frontend from `dist/public`

### Database Management
- **Schema Changes**: `npm run db:push` - Applies schema changes to database
- **Migrations**: Stored in `./migrations` directory
- **Environment**: Requires `DATABASE_URL` environment variable

### Architecture Decisions

**Frontend Framework Choice**: React with TypeScript provides type safety and component reusability. Wouter was chosen over React Router for its lightweight footprint.

**UI Library**: shadcn/ui with Radix UI primitives offers accessible, customizable components while maintaining design consistency.

**Backend Framework**: Express.js provides simplicity and familiarity for API development with good TypeScript support.

**Database Strategy**: Drizzle ORM was selected for its TypeScript-first approach and excellent developer experience. The storage interface allows for easy switching between implementations.

**Build Tools**: Vite offers superior development experience with fast HMR, while esbuild provides efficient production bundling for the server.

**State Management**: TanStack Query handles server state management, while local React state manages the rickroll progression for optimal user experience.